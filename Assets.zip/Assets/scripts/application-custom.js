﻿$(document).ready(function () {
    var handleDataTableButtons = function () {
        if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
                responsive: true,
                dom: "Bfrtip",
                buttons: [
                  {
                      extend: "copy",
                      className: "btn-sm"
                  },
                  {
                      extend: "csv",
                      className: "btn-sm"
                  },
                  {
                      extend: "excel",
                      className: "btn-sm"
                  },
                  {
                      extend: "pdfHtml5",
                      className: "btn-sm"
                  },
                  {
                      extend: "print",
                      className: "btn-sm"
                  },
                ]
            });
        }
    };

    TableManageButtons = function () {
        "use strict";
        return {
            init: function () {
                handleDataTableButtons();
            }
        };
    }();

    TableManageButtons.init();

    $('#datatable').DataTable({
        responsive: true
    });
    
    $('#entrydate').change(function () {
        $("#department").val($("#department option:first").val());
        $("#employees").empty();

        $('#entrydate').css('border-color', '');
        var dateToBeValidated = $('#entrydate').val()
        var validDate = validateForSunday(dateToBeValidated)
        if (!validDate) {
            alert("Week should always start on a Sunday")
            $('#entrydate').css('border-color', 'red');
            $('#entrydate').val('');
        }
        else {
            isCurrentorFuture(dateToBeValidated);
        }
       
    });

    $('#contWeekStartDate').datepicker();

    $('#contWeekStartDate').change(function () {
        $('#contWeekStartDate').css('border-color', '');
        var dateToBeValidated = $('#contWeekStartDate').val()
        var validDate = validateForSunday(dateToBeValidated)
        if (!validDate) {
            alert("Week should always start on a Sunday")
            $('#contWeekStartDate').css('border-color', 'red');
            $('#contWeekStartDate').val('');
        }
        else {
            isCurrentorFuture(dateToBeValidated);
        }
    });

});

function validateForSunday(inputDate) {
    var validatedDate = new Date(inputDate);
    var returnFlag = true;
    if (validatedDate.getDay() != 0) {
        returnFlag = false;
    }
    return returnFlag;
}

function isCurrentorFuture(inputDate)
{
    var selectedDate = new Date(inputDate); // get current date
    var firstSelect = selectedDate.getDate() - selectedDate.getDay(); // First day is the day of the month - the day of the week
    
    var curr = new Date();
    var firstcurr = curr.getDate() - curr.getDay();

    var firstdaySelected = new Date(selectedDate.setDate(firstSelect)).getDate();
    var firstdayCurr = new Date(curr.setDate(firstcurr)).getDate();
    if (firstdaySelected == firstdayCurr) {
        alert("You cannot select current week or future week.");
        $('#entrydate').css('border-color', 'red');
        $('#entrydate').val('');
        return false;
    }

    if (selectedDate > curr) {
        alert("You cannot select current week or future week.");
        $('#entrydate').css('border-color', 'red');
        $('#entrydate').val('');
        return false;
    }

   //alert(firstday);
}

function blockUI() {
    $('#blockUI').modal('show');
}

function UnblockUI() {
    $('#blockUI').modal('hide');
}